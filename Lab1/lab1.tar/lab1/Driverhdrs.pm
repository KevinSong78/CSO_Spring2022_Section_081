#
# This file contains course and lab specific parameters for drivers.
#
package Driverhdrs;

# This is no longer needed
$COURSE_NAME = "";

# No need to ever update these
$LAB = "lab1";
$SERVER_NAME = "spunky.cs.nyu.edu";
$SERVER_PORT = "80";
$AUTOGRADE_TIMEOUT = "300";
1;
